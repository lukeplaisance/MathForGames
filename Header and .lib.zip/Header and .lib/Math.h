#pragma once


	float Add(float lhs, float rhs)
	{
		float add = lhs + rhs;
		return add;
	}

	float Subtract(float lhs, float rhs)
	{
		float sub = lhs - rhs;
		return sub;
	}

	float Multiply(float lhs, float rhs)
	{
		float multi = lhs * rhs;
		return multi;
	}

	float Divide(float lhs, float rhs)
	{
		float div = lhs / rhs;
		return div;
	}
